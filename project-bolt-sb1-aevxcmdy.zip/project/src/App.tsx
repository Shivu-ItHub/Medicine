import React, { useState } from 'react';
import { Pill } from 'lucide-react';
import { ImageUpload } from './components/ImageUpload';
import { CameraCapture } from './components/CameraCapture';
import { MedicineDetails } from './components/MedicineDetails';
import { identifyMedicine } from './utils/mockIdentification';
import { IdentificationResult } from './types/medicine';

function App() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<IdentificationResult | null>(null);

  const handleImage = async (input: File | string) => {
    setIsLoading(true);
    try {
      const identificationResult = await identifyMedicine(input);
      setResult(identificationResult);
    } catch (error) {
      console.error('Error identifying medicine:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-5xl mx-auto px-4 py-4">
          <div className="flex items-center gap-2">
            <Pill className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">Medicine Identifier</h1>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                Upload Medicine Image
              </h2>
              <ImageUpload onImageSelect={handleImage} />
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                Capture with Camera
              </h2>
              <CameraCapture onImageCapture={handleImage} />
            </div>
          </div>

          <div>
            {isLoading ? (
              <div className="bg-white rounded-lg shadow-lg p-6 flex items-center justify-center min-h-[400px]">
                <div className="text-center">
                  <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                  <p className="text-gray-600">Analyzing medicine image...</p>
                </div>
              </div>
            ) : result ? (
              <MedicineDetails
                medicine={result.medicine}
                confidence={result.confidence}
              />
            ) : (
              <div className="bg-white rounded-lg shadow-lg p-6 flex items-center justify-center min-h-[400px]">
                <div className="text-center text-gray-500">
                  <p>Upload an image or use the camera to identify medicine</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;