import { Medicine, IdentificationResult } from '../types/medicine';
import { mockMedicines } from '../data/mockMedicines';

export async function identifyMedicine(imageFile: File | string): Promise<IdentificationResult> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  // Randomly select a medicine and confidence score
  const randomMedicine: Medicine = mockMedicines[Math.floor(Math.random() * mockMedicines.length)];
  const confidence = 85 + Math.random() * 10; // Random confidence between 85-95%
  
  return {
    confidence,
    medicine: randomMedicine
  };
}